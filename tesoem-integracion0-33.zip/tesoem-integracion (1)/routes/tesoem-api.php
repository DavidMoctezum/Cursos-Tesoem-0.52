<?php

use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\CategoriaController;
use App\Http\Controllers\Api\V1\CertificadoController;
use App\Http\Controllers\Api\V1\CursoController;
use App\Http\Controllers\Api\V1\InscripcionController;
use App\Http\Controllers\Api\V1\PerfilController;
use App\Http\Controllers\Api\V1\ProgresoController;
use App\Http\Controllers\Api\V1\ProyectoController;
use App\Http\Controllers\Api\V1\UsuarioController;
use Illuminate\Support\Facades\Route;

// Prefijo /api/v1 y grupo "web" definidos en bootstrap/app.php

// ---- Publico ----
Route::get('/csrf', [AuthController::class, 'csrf']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout']);
Route::post('/usuarios', [AuthController::class, 'registrar'])->middleware('throttle:10,1');

Route::get('/categorias', [CategoriaController::class, 'index']);
Route::get('/cursos', [CursoController::class, 'index']);
Route::get('/cursos/{curso}', [CursoController::class, 'show']);

// ---- Requiere sesion ----
Route::middleware('auth')->group(function () {
    Route::post('/categorias', [CategoriaController::class, 'store']);

    Route::get('/usuarios', [UsuarioController::class, 'index']);
    Route::put('/usuarios/{usuario}', [UsuarioController::class, 'update']);

    Route::post('/cursos', [CursoController::class, 'store']);
    Route::put('/cursos/{curso}', [CursoController::class, 'update']);
    Route::delete('/cursos/{curso}', [CursoController::class, 'destroy']);
    Route::post('/cursos/{curso}/aprobar', [CursoController::class, 'aprobar']);
    Route::post('/cursos/{curso}/rechazar', [CursoController::class, 'rechazar']);

    Route::post('/inscripcion', [InscripcionController::class, 'store']);
    Route::get('/inscripciones', [InscripcionController::class, 'index']);

    Route::post('/progreso', [ProgresoController::class, 'store']);

    Route::get('/perfil', [PerfilController::class, 'show']);
    Route::put('/perfil', [PerfilController::class, 'update']);

    Route::get('/proyectos', [ProyectoController::class, 'index']);
    Route::post('/proyectos', [ProyectoController::class, 'store']);

    Route::get('/certificados', [CertificadoController::class, 'index']);
});

/* ============================================================
   COMPONENTES COMPARTIDOS (usados en todas las páginas)
   ============================================================ */

/* Avisos flotantes (mensajes cortos tipo "Guardado", "Error") */
window.Toast = {
  mostrar(mensaje, tipo) {
    let zona = $("#toasts");
    if (!zona) {
      zona = document.createElement("div");
      zona.id = "toasts";
      document.body.appendChild(zona);
    }
    const t = document.createElement("div");
    t.className = "toast " + (tipo || "");
    t.setAttribute("role", "status");
    t.textContent = mensaje;
    zona.appendChild(t);
    setTimeout(() => t.remove(), 4000);
  },
  ok(m) { this.mostrar(m, "ok"); },
  error(m) { this.mostrar(m, "error"); },
};

/* ============================================================
   BARRA DE NAVEGACIÓN
   Izquierda: Menú (va al inicio) · Cursos (con menú desplegable
   de las 9 carreras) · Proyectos · buscador con lupa
   (si hay sesión iniciada, se agrega "Panel")
   Derecha: si NO hay sesión -> Iniciar sesión / Crear cuenta
            si SÍ hay sesión -> rol · nombre · Salir
   ============================================================ */
const ENLACES_IZQUIERDA = [
  { texto: "Menú", url: "/index.html", clase: "nav-boton-menu" },
  { texto: "Proyectos", url: "/pages/proyectos.html" },
];

// Las 9 carreras que se muestran en el desplegable de "Cursos".
// El "ancla" debe coincidir con el id de la sección en cursos.html
const CARRERAS_MENU = [
  { texto: "Sistemas Computacionales", ancla: "sistemas-computacionales" },
  { texto: "Ingeniería Ambiental", ancla: "ingenieria-ambiental" },
  { texto: "Contaduría", ancla: "contaduria" },
  { texto: "Ingeniería Industrial", ancla: "ingenieria-industrial" },
  { texto: "TICs", ancla: "tics" },
  { texto: "Sistemas Automotrices", ancla: "sistemas-automotrices" },
  { texto: "Ing. en Energías Renovables", ancla: "energias-renovables" },
  { texto: "Ing. en Administración", ancla: "administracion" },
  { texto: "Gastronomía", ancla: "gastronomia" },
];

window.Navbar = {
  pintar() {
    const host = $("#nav");
    if (!host) return;
    const s = Sesion.actual();
    const aqui = location.pathname;

    // --- Enlaces normales de la izquierda ---
    let enlaces = ENLACES_IZQUIERDA.slice();
    if (s) enlaces = enlaces.concat([{ texto: "Panel", url: "/pages/panel.html" }]);

    const links = enlaces
      .map((e) => {
        const activo = aqui.endsWith(e.url) ? ' aria-current="page"' : "";
        const clase = e.clase ? ' class="' + e.clase + '"' : "";
        return '<a href="' + ruta(e.url) + '"' + clase + activo + ">" + esc(e.texto) + "</a>";
      })
      .join("");

    // --- Menú desplegable de "Cursos" ---
    const opcionesCarreras = CARRERAS_MENU.map(
      (c) => '<a href="' + ruta("/pages/cursos.html") + "#" + c.ancla + '">' + esc(c.texto) + "</a>"
    ).join("");
    const dropdownCursos =
      '<div class="nav-dropdown">' +
      '<a href="' + ruta("/pages/cursos.html") + '">Cursos <span class="nav-flecha">▾</span></a>' +
      '<div class="nav-dropdown-menu">' + opcionesCarreras + "</div>" +
      "</div>";

    // --- Buscador con lupa ---
    const buscador =
      '<form class="nav-buscador" id="form-busqueda-nav" role="search">' +
      '<input type="search" id="busqueda-nav" placeholder="¿Qué curso buscas?" aria-label="Buscar curso">' +
      '<button type="submit" aria-label="Buscar">🔍</button>' +
      "</form>";

    // --- Lado derecho: sesión iniciada o invitado ---
    const zonaUsuario = s
      ? '<div class="nav-usuario"><span class="nav-rol">' +
        esc(Formato.rol(s.rol)) +
        '</span><a href="' + ruta("/pages/perfil.html") + '">' + esc(s.nombre || "Mi perfil") + "</a>" +
        '<button class="btn btn-sm btn-linea" id="btn-salir" style="color:#e6c9d2;border-color:#5c2536">Salir</button></div>'
      : '<div class="nav-usuario"><a href="' + ruta("/pages/login.html") + '">Iniciar sesión</a>' +
        '<a class="btn btn-sm btn-accion" href="' + ruta("/pages/registro.html") + '">Crear cuenta</a></div>';

    host.innerHTML = '<div class="shell fila fila-entre">' +
      '<nav class="nav-links">' + links.replace('<a href="' + ruta("/pages/proyectos.html") + '">Proyectos</a>', dropdownCursos + '<a href="' + ruta("/pages/proyectos.html") + '">Proyectos</a>') + "</nav>" +
      buscador +
      zonaUsuario +
      "</div>";

    const salir = $("#btn-salir");
    if (salir) {
      salir.addEventListener("click", async () => {
        try {
          await AuthService.logout();
        } catch (e) {
          /* aunque falle en el servidor, se cierra en el cliente */
        }
        Sesion.limpiar();
        location.href = ruta("/index.html");
      });
    }

    const formBusqueda = $("#form-busqueda-nav");
    formBusqueda.addEventListener("submit", (evento) => {
      evento.preventDefault();
      const texto = $("#busqueda-nav").value.trim();
      location.href = ruta("/pages/cursos.html") + (texto ? "?buscar=" + encodeURIComponent(texto) : "");
    });
  },
};

/* Tarjeta de curso usada en el catálogo y en los paneles. */
window.TarjetaCurso = function (curso) {
  return (
    '<a class="tarjeta-curso" href="' + ruta("/pages/curso.html") + "?id=" + encodeURIComponent(curso.id) + '">' +
    '<span class="etiqueta">' + esc(curso.categoria) + "</span>" +
    "<h3>" + esc(curso.titulo) + "</h3>" +
    '<p class="resumen">' + esc(curso.resumen || "") + "</p>" +
    '<span class="meta">' + esc(curso.profesor || "Por asignar") +
    " · " + esc(curso.duracion || "") +
    " · " + esc(curso.inscritos || 0) + " inscritos</span>" +
    "</a>"
  );
};

/* Barra de progreso segmentada: un tramo por lección. */
window.BarraProgreso = function (completadas, total) {
  const t = Math.max(total || 0, 1);
  let html = '<div class="progreso" role="img" aria-label="' + completadas + " de " + t + ' lecciones">';
  for (let i = 0; i < t; i++) html += "<i" + (i < completadas ? ' class="hecho"' : "") + "></i>";
  html += "</div>";
  html += '<p class="progreso-dato">' + completadas + " de " + t + " lecciones · " +
    Formato.porcentaje((completadas / t) * 100) + "</p>";
  return html;
};

document.addEventListener("DOMContentLoaded", () => Navbar.pintar());

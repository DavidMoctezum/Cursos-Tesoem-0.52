(function () {
  const id = new URLSearchParams(location.search).get("id");
  const hero = $("#hero");
  const contenido = $("#contenido");
  const lateral = $("#lateral");
  let curso = null;

  if (!id) {
    location.replace(ruta("/pages/cursos.html"));
    return;
  }

  async function cargar() {
    try {
      const r = await CursoService.obtener(id);
      curso = r.curso;
      pintar();
    } catch (e) {
      hero.innerHTML = '<div class="shell"><h1>No encontramos este curso</h1><p>' + esc(e.message) +
        '</p><a class="btn btn-accion" href="' + ruta("/pages/cursos.html") + '">Volver al catálogo</a></div>';
    }
  }

  function pintar() {
    document.title = curso.titulo + " · TESOEM";

    hero.innerHTML =
      '<div class="shell">' +
      '<span class="etiqueta etiqueta-amber">' + esc(curso.categoria) + "</span>" +
      "<h1>" + esc(curso.titulo) + "</h1>" +
      "<p>" + esc(curso.resumen) + "</p>" +
      '<p class="meta">' + esc(curso.profesor) + " · " + esc(curso.duracion) +
      " · " + esc(curso.nivel) + " · " + esc(curso.inscritos) + " inscritos</p>" +
      "</div>";

    contenido.innerHTML =
      "<h2>Sobre el curso</h2>" +
      '<p class="lectura">' + esc(curso.descripcion) + "</p>" +
      "<h2 style='margin-top:var(--s6)'>Contenido</h2>" +
      '<div id="lecciones"></div>' +
      (curso.materiales && curso.materiales.length
        ? "<h2 style='margin-top:var(--s6)'>Material de apoyo</h2>" +
          '<ul class="apilado" style="padding-left:1.1rem">' +
          curso.materiales
            .map((m) => "<li>" + esc(m.titulo) + ' <span class="etiqueta etiqueta-gris">' + esc(m.tipo) + "</span></li>")
            .join("") +
          "</ul>"
        : "");

    pintarLecciones();
    pintarLateral();
  }

  function pintarLecciones() {
    const vistas = curso.leccionesVistas || [];
    const puedeMarcar = curso.inscrito && Sesion.rol() === "ALUMNO";
    $("#lecciones").innerHTML = curso.lecciones
      .map((l, i) => {
        const hecha = vistas.includes(l.id);
        return (
          '<div class="leccion' + (hecha ? " completada" : "") + '">' +
          '<span class="num">' + String(i + 1).padStart(2, "0") + "</span>" +
          '<span class="titulo">' + esc(l.titulo) + "</span>" +
          (puedeMarcar
            ? hecha
              ? '<span class="etiqueta">Completada</span>'
              : '<button class="btn btn-sm btn-linea" data-leccion="' + l.id + '">Marcar vista</button>'
            : "") +
          "</div>"
        );
      })
      .join("");

    $$("[data-leccion]").forEach((b) =>
      b.addEventListener("click", () => marcar(b.dataset.leccion, b))
    );
  }

  async function marcar(idLeccion, boton) {
    boton.disabled = true;
    try {
      const r = await ProgresoService.marcarLeccion(curso.id, idLeccion);
      curso.leccionesVistas.push(idLeccion);
      pintarLecciones();
      pintarLateral();
      if (r.porcentaje === 100) Toast.ok("Terminaste el curso. Tu certificado ya está en tu panel.");
      else Toast.ok("Progreso guardado: " + Formato.porcentaje(r.porcentaje));
    } catch (e) {
      Toast.error(e.message);
      boton.disabled = false;
    }
  }

  function pintarLateral() {
    const rol = Sesion.rol();
    let html = '<div class="tarjeta">';

    if (curso.inscrito) {
      const vistas = (curso.leccionesVistas || []).length;
      html +=
        "<h3>Tu avance</h3>" +
        BarraProgreso(vistas, curso.lecciones.length) +
        '<a class="btn btn-linea btn-bloque" style="margin-top:var(--s4)" href="' +
        ruta("/pages/panel.html") + '">Ver mis cursos</a>';
    } else if (rol === "ALUMNO") {
      html +=
        "<h3>Inscríbete</h3>" +
        '<p class="silencio">' + esc(curso.duracion) + " · nivel " + esc(curso.nivel) + "</p>" +
        '<button class="btn btn-accion btn-bloque" id="btn-inscribir">Inscribirme</button>';
    } else if (!rol) {
      html +=
        "<h3>Inscríbete</h3>" +
        '<p class="silencio">Necesitas una cuenta de alumno para tomar este curso.</p>' +
        '<a class="btn btn-accion btn-bloque" href="' + ruta("/pages/login.html") +
        "?volver=" + encodeURIComponent(location.pathname + location.search) + '">Iniciar sesión</a>';
    } else if (rol === "EMPRESA") {
      html +=
        "<h3>¿Te interesa esta capacitación?</h3>" +
        '<p class="silencio">Contacta a ' + esc(curso.profesor) + " para acordar un grupo para tu personal.</p>" +
        '<a class="btn btn-linea btn-bloque" href="' + ruta("/pages/proyectos.html") + '">Ver proyectos de alumnos</a>';
    } else if (rol === "PROFESOR" && curso.idProfesor === (Sesion.actual() || {}).id) {
      html +=
        "<h3>Administrar</h3>" +
        '<a class="btn btn-linea btn-bloque" href="' + ruta("/pages/curso-editor.html") + "?id=" + curso.id + '">Editar curso</a>';
    } else {
      html += "<h3>Ficha del curso</h3><p class=\"silencio\">" + esc(curso.duracion) + " · " + esc(curso.nivel) + "</p>";
    }

    html += "</div>";
    lateral.innerHTML = html;

    const btn = $("#btn-inscribir");
    if (btn) {
      btn.addEventListener("click", async () => {
        btn.disabled = true;
        btn.textContent = "Inscribiendo…";
        try {
          await InscripcionService.inscribir(curso.id);
          Toast.ok("Listo, ya estás inscrito.");
          curso.inscrito = true;
          curso.leccionesVistas = [];
          curso.inscritos += 1;
          pintar();
        } catch (e) {
          Toast.error(e.message);
          btn.disabled = false;
          btn.textContent = "Inscribirme";
        }
      });
    }
  }

  cargar();
})();
